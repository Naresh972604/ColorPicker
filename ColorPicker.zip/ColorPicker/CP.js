
$( document ).ready(function() {
    $("#headBG").spectrum({
        color:'#dc3545',
        move: function(cl){
            let c=cl.toHexString();
            $("#bgHead").css({"background-color": c});
        },
        change: function(cl){
            let c=cl.toHexString();
            $("#bgHead").css({"background-color": c});
        }
    });
    $("#headName").spectrum({
        color:'white',
        move: function(cl){
            let c=cl.toHexString();
            $("#userName").css({"color": c});
        },
        change: function(cl){
            let c=cl.toHexString();
            $("#userName").css({"color": c});
        }
    });
    $("#headButtonColor").spectrum({
        color:'white',
        move: function(cl){
            let c=cl.toHexString();
            $("#contact").css({"background-color": c});
        },
        change: function(cl){
            let c=cl.toHexString();
            $("#contact").css({"background-color": c});
        },

    });
    $("#headMenuTextColor").spectrum({
        color:'white',
        move: function(cl){
            let c=cl.toHexString();
            $(".menuItem").css({"color": c});
        },
        change: function(cl){
            let c=cl.toHexString();
            $(".menuItem").css({"color": c});
        }
    });
    $("#headDesignationColor").spectrum({
        color:'white',
        move: function(cl){
            let c=cl.toHexString();
            $("#userRole").css({"color": c});
        },
        change: function(cl){
            let c=cl.toHexString();
            $("#userRole").css({"color": c});
        }
    });
    $("#headContactButtonText").spectrum({
        color:'black',
        move: function(cl){
            let c=cl.toHexString();
            $("#contact").css({"color": c});
        },
        change: function(cl){
            let c=cl.toHexString();
            $("#contact").css({"color": c});
        }
    });
});


